 <!-- footer area start -->
 <footer class="main-footer bgc-black pt-60 rpt-100 rel z-1"
     style="background-image: url(assets/images/background/footer-bg.png);">
     <div class="widget-area pb-70">
         <div class="container">
             <div class="row">
                 <div class="col-xl-12 text-center">
                     <div class="footer-widget footer-text" data-aos="fade-up" data-aos-duration="1500"
                         data-aos-offset="0">
                         <div class="footer-logo mb-25">
                             <a href="index.html"><img src="assets/images/logo.webp" alt="Logo"></a>
                         </div>
                         <p>Visit Joy’s Biryani N Kababs in Pineville, NC to taste Indian dishes that are bursting
                             <br>with
                             flavor, aromatic spices, and bold flavors.</p>
                         <div class="social-style-one mt-15">
                             <a href="https://www.facebook.com/joysbiryaniandkabab" target="_blank"><i
                                     class="fab fa-facebook-f"></i></a>

                             <a href="https://www.instagram.com/joysbiryani" target="_blank"><i
                                     class="fab fa-instagram"></i></a>
                         </div>

                         <!-- <h5>Quick Links</h5> -->
                         <ul class="footer-link mt-4">
                             <li><a href="index.php">Home</a></li>
                             <li><a href="our-story.php">Our Story</a></li>
                             <li><a href="menu.php">Menu</a></li>
                             <li><a href="catering.php">Catering</a></li>
                             <li><a href="gallery.php">Gallery</a></li>
                             <li><a href="reservation.php">Reservation</a></li>
                             <!-- <li><a href="career.php">Now Hiring</a></li> -->
                         </ul>
                         <!-- <h5>contact us</h5> -->
                         <p class="mt-4"><i class="fa fa-map-marker-alt"></i>    212 N Polk St #101, Pineville, NC 28134, United States. <br>
                         <i class="fa fa-phone" style=" rotate: 90deg;"></i>  
                             +17048351285 / +17048351286</p>
                         <p>Monday to Sunday : <span>11:00AM – 10:00PM</span> (opening hour)</p>

                     </div>
                 </div>
             </div>
         </div>
     </div>
     <div class="footer-bottom pt-30 pb-15">
         <div class="container">
             <div class="row">
                 <div class="col-lg-5">
                     <div class="copyright-text text-center">
                         <p>Copyright 2025 <a href="index.php">Metro Pizza</a>. All Rights Reserved </p>
                     </div>
                 </div>
                 <div class="col-lg-7 text-center text-lg-end">
                     <ul class="footer-bottom-nav">
                         <li><a href="order-terms.php">Order Terms</a></li>
                         <li><a href="terms-of-use.php">Terms of Use</a></li>
                         <li><a href="privacy-policy.php">Privacy Policy</a></li>
                         <li><a href="accessibility.php">Accessibility Statement</a></li>


                     </ul>
                 </div>
             </div>
             <!-- Scroll Top Button -->
             <button class="scroll-top scroll-to-target" data-target="html"><i class="fas fa-arrow-alt-up"></i></button>
         </div>
     </div>
 </footer>
 <!-- footer area end -->

 </div>
 <!--End pagewrapper-->

 </script>
 <script src='https://cdn.jotfor.ms/s/umd/latest/for-embedded-agent.js'></script>
<script>
  window.addEventListener("DOMContentLoaded", function() {
    window.AgentInitializer.init({
      agentRenderURL: "https://agent.jotform.com/01959cafcc387f2b8ac4b58bc6a9e8ff07b5",
      rootId: "JotformAgent-01959cafcc387f2b8ac4b58bc6a9e8ff07b5",
      formID: "01959cafcc387f2b8ac4b58bc6a9e8ff07b5",
      queryParams: ["skipWelcome=1", "maximizable=1"],
      domain: "https://www.jotform.com",
      isDraggable: false,
      background: "linear-gradient(180deg, #EBF5FF 0%, #F8D4F1 100%)",
      buttonBackgroundColor: "#0A1551",
      buttonIconColor: "#FFF",
      variant: false,
      customizations: {
        "greeting": "Yes",
        "greetingMessage": "Hi! How can I assist you?",
        "openByDefault": "No",
        "pulse": "Yes",
        "position": "right",
        "autoOpenChatIn": "10000"
      },
      isVoice: undefined
    });
  });
</script>
 <!--End of Tawk.to Script-->

 <!-- Jquery -->
 <script src="assets/js/jquery-3.6.0.min.js"></script>
 <!-- Bootstrap -->
 <script src="assets/js/bootstrap.min.js"></script>
 <!-- Appear Js -->
 <script src="assets/js/appear.min.js"></script>
 <!-- Slick -->
 <script src="assets/js/slick.min.js"></script>
 <!-- Magnific Popup -->
 <script src="assets/js/jquery.magnific-popup.min.js"></script>
 <!-- Nice Select -->
 <script src="assets/js/jquery.nice-select.min.js"></script>
 <!-- Image Loader -->
 <script src="assets/js/imagesloaded.pkgd.min.js"></script>
 <!-- Circle Progress -->
 <script src="assets/js/circle-progress.min.js"></script>
 <!-- Skillbar -->
 <script src="assets/js/skill.bars.jquery.min.js"></script>
 <!-- Isotope -->
 <script src="assets/js/isotope.pkgd.min.js"></script>
 <!--  AOS Animation -->
 <script src="assets/js/aos.js"></script>
 <!-- Custom script -->
 <script src="assets/js/script.js"></script>

 </body>

 </html>