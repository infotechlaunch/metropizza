<!-- Testimonials Two Area start -->
<section class="testimonials-two bgc-primary"
    style="background-image: url(assets/images/testimonials/testimonials-two-bg.png);">
    <div class="row align-items-center">
        <div class="col-lg-6">
            <div class="why-choose-two-image">
                <img src="assets/images/testimonial-img.png" alt="Testimonials">
            </div>
        </div>
        <div class="col-lg-6">
            <div class="testimonials-two-content rel z-1 text-center text-white p-45 rpy-55">
                <div class="section-title mb-20" data-aos="fade-up" data-aos-duration="1500" data-aos-offset="50">
                    <span class="sub-title mb-5"> Check out our most recent reviews!</span>
                    <h2>Our customers Say!</h2>
                </div>
                <!-- <span class="marquee-wrap style-two">
                    <span class="marquee-inner left">review </span>
                    <span class="marquee-inner left">review </span>
                    <span class="marquee-inner left">review </span>
                </span> -->
                <div class="testimonials-two-carousel" data-aos="fade-up" data-aos-delay="50" data-aos-duration="1500"
                    data-aos-offset="50">
                    <div class="testimonial-two-item">
                        <div class="quote"><i class="flaticon-quote"></i></div>
                        <div class="text">This is the best Indian food I had in long time!! Truly satisfied that my
                            taste buds are so happy. Please order HALEEM when you visit this season. Pomfret is amazing.
                            I would recommend to everyone. If you’re not going there, you’re missing out on some
                            delicious food. Ignore the fake reviews.
                        </div>
                        <span class="author"><img src="assets/images/testimonials/sravani-vemireddy.png"> sravani
                            vemireddy</span>
                    </div>
                    <div class="testimonial-two-item">
                        <div class="quote"><i class="flaticon-quote"></i></div>
                        <div class="text">I recently had the pleasure of dining at Joy Kebab, and I have to say, the
                            experience was wonderful. The food here is not only delicious but has that comforting,
                            home-cooked feel that’s hard to find at most restaurants. Every bite is flavorful and made
                            with care, reminding me of a meal cooked by a loved one. If you’re looking for a place that
                            serves great food with a touch of home, Joy Kebab is the place to go. Highly recommended!
                        </div>
                        <span class="author"><img src="assets/images/testimonials/Sasi-Soorya.png">Sasi Soorya</span>
                    </div>
                    <div class="testimonial-two-item">
                        <div class="quote"><i class="flaticon-quote"></i></div>
                        <div class="text">Halal restaurant. The chicken 65 biryani is the best! The Tikka masala and
                            butter chicken are ok. I'd rate them a 3/5. But i would go just for the chicken 65 biryani.
                            that's a 5/5. The dosa was also pretty good but it is very big. There is comfortable seating
                            inside the restaurant.
                        </div>

                        <span class="author"><img src="assets/images/testimonials/Romeooh.png">Romeooh</span>
                    </div>
                    <div class="testimonial-two-item">
                        <div class="quote"><i class="flaticon-quote"></i></div>
                        <div class="text">Went in today to try this fantastic place. Just happy to eat one the most yummiest food! LOVED THEIR GRILLED FISH! One of the Best! Can’t recommend this enough!! Their famous Gosat biryani and their Garlic fried rice was piping hot and very flavorful. Combine that with their speciality kabab!!! 🩷. The restaurant owner and chef did a marvelous job bringing home cooked style comfort food!
                        </div>

                        <span class="author"><img src="assets/images/testimonials/Perumalla-Family.png">Perumalla Family</span>
                    </div>
                    <div class="testimonial-two-item">
                        <div class="quote"><i class="flaticon-quote"></i></div>
                        <div class="text">Stopped in after arriving from Minneapolis based on recommendations from friends and family that live in the area. We were literally the only couple dining in but the service was excellent, quick and courteous. Food was hot, fresh and delicious. We got the veggie samosas, chicken Tikka kababs, garlic Naan and Hakka noodles. Every dish was excellent. The noodles were unexpectedly one of our favorite dishes - so much flavor! The look of this place is unassuming but the food and service are excellent! Don't miss out
                        </div>

                        <span class="author"><img src="assets/images/testimonials/Andrew-Miles.png">Andrew Miles</span>
                    </div>
                    <div class="testimonial-two-item">
                        <div class="quote"><i class="flaticon-quote"></i></div>
                        <div class="text">My goodness the samosas taste heavenly, the flour that they used turned out so soft and chewy blending in perfectly with vegetables. THIS IS THE BEST SAMOSAS IVE EVE
                        </div>

                        <span class="author"><img src="assets/images/testimonials/Tom-Swindal.png">Tom Swindal</span>
                    </div>
                    <div class="testimonial-two-item">
                        <div class="quote"><i class="flaticon-quote"></i></div>
                        <div class="text">A hidden gem tucked away in Pineville. This was our first time coming to Joy’s
                            Biryani and the experience was phenomenal. We ordered their chicken dum biryani and chili
                            garlic chicken fry and it was absolutely delicious. It was so fresh and filled with flavour.
                            The biryani we had today was amazing and it tasted just the way I would eat at home. Very
                            comforting. We have been to numerous Indian restaurants and they don’t compare to what we
                            ate here today. They also have a bakery and ordered three types of cake slices which were
                            just as tasty. I recommend the ras malai cake as it was very moist and tasted the exact. The
                            service was great as well and the restaurant itself was very clean. I highly recommend this
                            place to everyone who would like to try and/or enjoys our desi cuisine. The best part is
                            that it was halal! Joy’s Biryani has a new loyal customer.</div>

                        <span class="author"><img src="assets/images/testimonials/Mariam-Khan.png">Mariam Khan</span>
                    </div>
                    <div class="testimonial-two-item">
                        <div class="quote"><i class="flaticon-quote"></i></div>
                        <div class="text">A small restaurant with limited number of parking spaces. We went there on
                            Saturday before dinner time, so there were not many customers.
                            Ordered an appetizer, dosa, and one from the traditional dish section. All tasted good.
                            Chicken 65 was flavored nicely; not much spicy but pretty impressive.
                            Good option for family dinner or casual meal. Servers were helpful and took care of our
                            orders.</div>

                        <span class="author"><img src="assets/images/testimonials/Siran-Tang.png">Siran Tang</span>
                    </div>
                </div>
                <div class="shape">
                    <img src="assets/images/shapes/tomato.png" alt="Shape">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonials Two Area end -->