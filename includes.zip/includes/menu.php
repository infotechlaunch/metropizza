<section class="Biryani-area pt-100 rpb-70 pb-130 rpb-100 rel z-1">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="section-title text-center mb-50" data-aos="fade-up" data-aos-duration="1500"
                    data-aos-offset="50">
                    <span class="sub-title mb-5">From Our Menu</span>
                    <h2>explore popular delicious Food</h2>
                </div>
            </div>
            <div class="col-lg-3">
                <ul class="nav food-menu-tab mb-40" role="tablist" data-aos="fade-up" data-aos-delay="50"
                    data-aos-duration="1500" data-aos-offset="50">
                    <li>
                        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#FamilyCombo">
                            <span>Family Combo</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#Kababs">
                            <span>Kababs</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#VegetarianAppetizers">
                            <span>Vegetarian Appetizers</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#Eggetarian">
                            <span>Eggetarian</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#NonVegAppetizers">
                            <span>Non Veg Appetizers</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#VegCurry">
                            <span>Veg Curry</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#NonVegCurry">
                            <span>Non - Veg Curry</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#BiryaniCornerRice">
                            <span>Biryani Corner/Rice</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#IndoChinese">
                            <span>Indo-Chinese</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#DosaCorner">
                            <span>Dosa - Corner</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#ParthaCorner">
                            <span>Partha Corner</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#IndianBreadRotisNaans">
                            <span>Indian Bread (Rotis/Naans)</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#Condiments">
                            <span>Condiments</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#Desserts">
                            <span>Desserts</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#Specials">
                            <span>Specials</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#Chat">
                            <span>Chat </span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#CakeandBakery">
                            <span>Cake & Bakery</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#Pickles">
                            <span>Pickles</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#FamilyPackBiryaniOnly">
                            <span>Family Pack Biryani Only</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#IndianTiffinsMenu">
                            <span>Indian Tiffins Menu</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#Beverages">
                            <span>Beverages</span>
                        </button>
                    </li>
                    <li>
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#Buffet">
                            <span>Buffet</span>
                        </button>
                    </li>
                </ul>
            </div>
            <div class="col-lg-9">
                <div class="food-menu-tab-content tab-content">
                    <div class="tab-pane fade  show active" id="FamilyCombo">
                        <div class="row">
                            <div class="col-lg-12">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Family-Combo.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Family Combo</span> <span
                                                    class="dots"></span> <span class="price">$46.99</span></h5>
                                            <p> 4 items of your choice a) Chicken Biryani or 65 Biryani or Boneless
                                                Biryani
                                                or Vijawada Biryani b) 1 - Butter Naan or Plain Naan or Garlic Naan c)
                                                Chicken 65 or Chk Chilli or Chk Manchuria d ) 1 Curry (Chicken Kadai,
                                                Tikka
                                                or Butter, Rojanjosh)</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mutton-Family-Combo.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mutton Family Combo</span> <span
                                                    class="dots"></span> <span class="price">$51.99</span></h5>
                                            <p>4 items of your choice a) Goat Biryani or Lamb Biryani b) 1 - Butter Naan
                                                or
                                                Plain Naan or Garlic Naan c) Chicken 65 4 ) 1 Curry (Chicken Tikka or
                                                Butter
                                                Chicken)</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Family-Combo.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Veg Family Combo</span> <span class="dots"></span>
                                                <span class="price">$43.99</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Panner-Family-Combo.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Panner Family Combo</span>
                                                <span class="dots"></span> <span class="price">$44.99</span>
                                            </h5>
                                            <p>Panner Biryani (48 OZ) , 1 item Panner or Veg Curry from the menu (
                                                Default
                                                is Panner Butter Masala), 1 Item of Veg apetizer from the menu ( Default
                                                is
                                                Panner Chilli ) , 1 Butter Naan or Plan Naan ( Default Butter Naan)</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Thalapakattu-Mutton-Family-Combo.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Thalapakattu Mutton Family Combo </span> <span
                                                    class="dots"></span>
                                                <span class="price">$54.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="Kababs">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Achari-Panner-Tikka.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Acari Panner Tikka Kabab</span> <span
                                                    class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Cubbed paneer marinated with achari masala in yogurt, skewed in the clay
                                                oven with Onions and bell peppers</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Chapli-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Chapli Kabab (Peshawari Kabab)</span><span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Chicken Chapli Kabab also known as Peshawari Kabab is absolutely tender
                                                chicken keema meat infused with such flavorful spices & given a flat
                                                disc
                                                shape resembling a patty.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Garlic-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Garlic Kabab</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Hariyala-Tikka.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Hariyala Tikka</span> <span
                                                    class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Boneless Chicken, Marinated in yogurt and green herbs with special
                                                spices,
                                                grilled on the skewer in the clay oven</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Malai-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Malai Kabab</span><span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Juicy, melt in the mouth chicken kabab on skewers made with tender pieces
                                                of
                                                chicken breast which are marinated in a paste of yogurt, almonds, heavy
                                                cream and spices like nutmeg and cardamom.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Seekh-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Seekh Kabab ( 2 Skewers)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p> Minced chicken marinated in yogurt and green herbs with special spices
                                                grilled on the skewer in the clay oven</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Tangdi-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Tangdi Kabab</span> <span
                                                    class="dots"></span>
                                                <span class="price">$18.99</span>
                                            </h5>
                                            <p>Tangdi Kabab is made with chicken drumsticks, spices, curd, and most
                                                often
                                                cream in a clay oven. (You get 3 or 4 pieces per order based on size )
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Seekh-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Seekh Kabab</span><span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Minced Lamb flavored with fresh herbs and spices, cooked in a clay oven
                                                skewers</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Boti-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Boti Kabab</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mixed-Grill-Non-Veg.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mixed Grills </span> <span class="dots"></span>
                                                <span class="price">$34.99</span>
                                            </h5>
                                            <p>Tandoori 2 Legs, 1 Chicken Sheek Kabab, 1 Lamb kabab, Pilau rice, 2 Naan
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Panner-Tikka-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Paneer Tikka Kabab (Veg)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p>Cubed Panner Marinated in Yogurt, skewered in the clay oven with onions
                                                and bell
                                                peppers</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Chicken-Full.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoor Chicken (Full)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$21.99</span>
                                            </h5>
                                            <p>Chicken marinated in yogurt blended with fresh ginger, garlic, herbs, and
                                                spices
                                                overnight and then cooked in a tandoor clay oven</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Chicken-Half.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoor Chicken (Half)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Chicken marinated in yogurt blended with fresh ginger, garlic, herbs, and
                                                spices
                                                overnight and then cooked in a tandoor clay oven</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Jhingha.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoori Jhingha</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>Fresh Shrimp in special tandoori spices and grilled on a skewer in a clay
                                                oven
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandori-Vegetables.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoori Vegetables</span> <span
                                                    class="dots"></span>
                                                <span class="price"><s>$15.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                            <p>Season able Vegetables</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Legs.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoori Legs (2)</span><span class="dots"></span>
                                                <span class="price">$11.99</span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Thiraga-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Thiraga Kabab</span> <span class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Chops.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Chops (5)</span><span class="dots"></span>
                                                <span class="price"><s>$25.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                            <!-- <p>Marinate the lamb chops in a mixture of herbs, garlic, olive oil, salt and
                                        pepper. ;
                                        Sear the chops on high heat on the stovetop until browned on both sides.</p> -->
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Fish-Whole-with-Bone.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoori Fish - Whole with Bone</span> <span
                                                    class="dots"></span>
                                                <span class="price">$19.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="VegetarianAppetizers">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/555-Paneer.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">555 Paneer
                                                </span> <span class="dots"></span> <span class="price">$13.99</span>
                                            </h5>
                                            <p> 5 Masalas used to marinate this panner and fried in Andhra Style</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chilli-Gobi.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chilli Gobi</span> <span class="dots"></span> <span
                                                    class="price">$11.99</span>
                                            </h5>
                                            <p>A crispy texture with a spicy, sweet and sour taste. The cauliflower
                                                florets are
                                                batter-coated, deep fried and then mixed with stir-fried onions, green
                                                bell
                                                pepper, soy sauce, sweet red chilli sauce, salt and pepper.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chilly-Paneer.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chilly Paneer</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p>Chilli Panner has crisp batter fried paneer tossed in slightly sweet,
                                                spicy, hot,
                                                and sour chili sauce. While Garlic and green chilies bring in a hot &
                                                pungent
                                                aroma, sauces like chili soya and vinegar are used to impart some
                                                Chinese
                                                flavor.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Crispy-Chilli-Baby-Corn.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Crispy Chilli Baby Corn
                                                </span> <span class="dots"></span> <span class="price">$11.99</span>
                                            </h5>
                                            <p> A crispy and mouth-watering finger-food with fried baby corn tossed in a
                                                fiery
                                                and garlicky sauce and topped with sesame seeds.
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Cut-Mirchi-Bhaji.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Cut Mirchi Bhaji</span> <span class="dots"></span>
                                                <span class="price">$6.99</span>
                                            </h5>
                                            <p>Chili fritters batter fried and cut</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Gobi-65.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Gobi 65</span> <span class="dots"></span> <span
                                                    class="price">$11.99</span></h5>
                                            <p>A dry preparation of cauliflower pieces marinated in yogurt and spicy
                                                chef's
                                                masala.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Gobi-Manchurian.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Gobi Manchurian</span> <span class="dots"></span>
                                                <span class="price">$11.99</span>
                                            </h5>
                                            <p>It features ridiculously crispy and crunchy fried cauliflower florets
                                                coated in a
                                                sweet, tangy, pleasant, savory taste of chili sauce with lots of
                                                aromatics. </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mixed-Veg-Pakora.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mixed Veg Pakora
                                                </span> <span class="dots"></span> <span class="price">$8.99</span></h5>
                                            <p>Deliciously spiced Veg fritters.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Onion-Pakora.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Onion Pakora</span>
                                                <span class="dots"></span> <span class="price">$7.99</span>
                                            </h5>
                                            <p> Deliciously spiced Onion fritters.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Paneer-Manchurian.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Paneer Manchurian</span> <span class="dots"></span>
                                                <span class="price">$12.99</span></h5>
                                            <p>Paneer cubes stir fried with hot chillies, ginger, garlic, spring onion
                                                in a
                                                special sauce.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Platter.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Veg Platter</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p> Pakoda, Spring roll (2), Samosa (2)</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Samosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Veg Samosa</span> <span class="dots"></span>
                                                <span class="price">$4.99</span>
                                            </h5>
                                            <p>2 pieces triangle pastry stuffed with potatoes and green peas.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Panner-Pokora.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Panner Pokora</span> <span class="dots"></span>
                                                <span class="price">$11.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lijjat-papad.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lijjat papad</span><span class="dots"></span>
                                                <span class="price">$1.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Gobi-Karapodi.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Gobi Karapodi</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="Eggetarian">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Hyderabadi-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Hyderabadi Masala</span> <span
                                                    class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Bhurji.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Bhurji (Indian Anda Bhurji)</span> <span
                                                    class="dots"></span> <span class="price">$10.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Butter-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Butter Masala (Egg Makhani)</span> <span
                                                    class="dots"></span> <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Curry-Kadai.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Curry - Kadai</span>
                                                <span class="dots"></span> <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Tikka-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Tikka Masala</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/South-Indian-Egg-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">South Indian Egg Curry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Fried-Rice.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Fried Rice</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Pakoda.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Pakoda</span> <span class="dots"></span>
                                                <span class="price">$9.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Two-Paratha-with-Egg-curry.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Two Paratha with Egg curry ( 8 oz)</span><span
                                                    class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Hakka-Noodles.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Hakka Noodles</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Kothu-Paratha.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Kothu Paratha</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="NonVegAppetizers">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/555-Chicken.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">555 Chicken</span> <span class="dots"></span> <span
                                                    class="price">$13.99</span></h5>
                                            <p>5 Masalas used to marinate this panner and fried in Andhra Style</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-65.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken 65 </span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p>Diced boneless Chicken tossed with green bell pepper, onion and spicy
                                                house sauce
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Fry-Street-Food-Style.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Fry Street Food Style
                                                </span> <span class="dots"></span> <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Manchurian.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Manchurian</span> <span class="dots"></span>
                                                <span class="price">$13.99</span></h5>
                                            <p> Tender boneless chicken stir fried with hot chillies, ginger, garlic,
                                                spring
                                                onion and special sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Pakora.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Pakora</span> <span class="dots"></span>
                                                <span class="price">$13.99</span></h5>
                                            <p>Thigh Chicken cubes Marinated with Indian Masalas and fried in oil</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Samosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Samosa</span> <span class="dots"></span>
                                                <span class="price">$9.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Sukka.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Sukka</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Dry chicken cooked with Indian spices and Herbs</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chili-Chicken.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chili Chicken</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p>Diced boneless Chicken tossed with green bell pepper,onion and spicy
                                                house sauce
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Pakora.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Pakora</span> <span class="dots"></span> <span
                                                    class="price">$10.99</span></h5>
                                            <p>Egg fritters batter fried and topped with onion...</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Amritsari.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Amritsari</span> <span class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p> Fish coated in a spiced gram flour batter and deep-fried till the
                                                outside is
                                                crunchy and fish inside is soft</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Sukka.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Sukka</span> <span class="dots"></span> <span
                                                    class="price">$16.99</span></h5>
                                            <p>Dry Goat cooked with indian spices and Herbs</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Kodi-Veguru-Andhra-Style.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Kodi Veguru Andhra Style</span> <span
                                                    class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Pepper-Fry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Pepper Fry</span> <span class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p>Pepper fry is zesty, spicy dish quite famous</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Madurai-Malli-Chicken.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Madurai Malli Chicken</span> <span
                                                    class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Boneless Chicken sauteed with ground cilantro sauce with a regional
                                                recipe of</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Pepper-Fry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Pepper Fry</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Pepper fry is zesty, spicy dish quite famous</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Fish-Whole-with-Bone.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoori Fish Whole with Bone</span> <span
                                                    class="dots"></span> <span class="price">$19.99</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tawa-Fish.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tawa Fish</span> <span class="dots"></span> <span
                                                    class="price">$16.99</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chili-Chicken.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chili Chicken</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p>Diced boneless Chicken tossed with green bell pepper,onion and spicy
                                                house sauce
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-65.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken 65</span> <span class="dots"></span> <span
                                                    class="price">$12.99</span></h5>
                                            <p>Diced boneless Chicken tossed with green bell pepper, onion and spicy
                                                house sauce
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Lollipop.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Lollipop</span> <span class="dots"></span>
                                                <span class="price">$10.99</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Sukka.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Sukka</span> <span class="dots"></span>
                                                <span class="price">$13.99</span></h5>
                                            <p>Dry chicken cooked with Indian spices and Herbs</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Chicken-Full.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoor Chicken (Full)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$21.99</span>
                                            </h5>
                                            <p>Chicken marinated in yogurt blended with fresh ginger, garlic, herbs, and
                                                spices
                                                overnight and then cooked in a tandoor clay oven</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Seekh-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Seekh Kabab ( 2 Skewers)</span> <span
                                                    class="dots"></span> <span class="price">$14.99</span></h5>
                                            <p>Minced chicken marinated in yogurt and green herbs with special spices
                                                grilled on
                                                the skewer in the clay oven</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Malai-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Malai Kabab</span> <span
                                                    class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Juicy, melt in the mouth chicken kabab on skewers made with tender pieces
                                                of
                                                chicken breast which are marinated in a paste of yogurt, almonds, heavy
                                                cream and spices like nutmeg and cardamom.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Chapli-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Chapli Kabab (Peshawari Kabab)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Chicken Chapli Kabab also known as Peshawari Kabab is absolutely tender
                                                chicken keema meat infused with such flavorful spices & given a flat
                                                disc
                                                shape resembling a patty.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Chicken-Half.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoor Chicken (Half)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Chicken marinated in yogurt blended with fresh ginger, garlic, herbs, and
                                                spices overnight and then cooked in a tandoor clay oven</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/555-Chicken.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">555 Chicken</span><span class="dots"></span> <span
                                                    class="price">$13.99</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Madurai-Malli-Chicken.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Madurai Malli Chicken</span> <span
                                                    class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Boneless Chicken sauteed with ground cilantro sauce with a regional
                                                recipe
                                                of</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Samosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Samosa</span> <span class="dots"></span>
                                                <span class="price">$9.99</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Hariyala-Tikka.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Hariyala Tikka</span> <span
                                                    class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p> Boneless Chicken, Marinated in yogurt and green herbs with special
                                                spices,
                                                grilled on the skewer in the clay oven</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Garlic-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Garlic Kabab</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Puff.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Puff</span> <span class="dots"></span> <span
                                                    class="price">$4.25</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Sukka.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Sukka</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Dry Goat cooked with indian spices and Herbs</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Sukka.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Sukka</span> <span class="dots"></span> <span
                                                    class="price">$14.99</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Seekh-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Seekh Kabab</span> <span class="dots"></span>
                                                <span class="price">$16.99</span></h5>
                                            <p>Minced Lamb flavored with fresh herbs and spices, cooked in a clay oven
                                                skewers
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Pepper-Fry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Pepper Fry</span> <span class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p>Pepper fry is zesty, spicy dish quite famous</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Boti-Kabab.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Boti Kabab</span> <span class="dots"></span>
                                                <span class="price">$16.99</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Chops.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Chops (5)</span> <span class="dots"></span>
                                                <span class="price">$25.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="VegCurry">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Aloo-Gobi-Korma.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Aloo Gobi Korma </span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Aloo gobi is a popular vegetarian Indian dish made with potatoes,
                                                cauliflower,
                                                spices, and herbs.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Amul-Cheese-Butter-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Amul Cheese Butter Masala</span> <span
                                                    class="dots"></span>
                                                <span class="price">$18.99</span>
                                            </h5>
                                            <p>A famous Punjabi Amul cheese with Palak</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Amul-Cheese-Garlic-Palak.jpg"
                                                alt="Amul Cheese Garlic Palak">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Amul Cheese Garlic Palak</span> <span
                                                    class="dots"></span>
                                                <span class="price">$18.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Bhindi-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Bhindi Masala</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>This is a semi-dry preparation featuring the star ingredient okra pods
                                                (bhindi in
                                                Hindi), piquant onions, tangy tomatoes, bold Indian spices, and herbs.
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chana-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chana Masala</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>1-pot chana masala with green chili, cilantro, and garam masala.
                                                Flavorful, not
                                                too spicy, and extremely satisfying. A healthy, plant-based meal</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chana-Saag.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chana Saag</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Chana Saag is a classic Indian curry made with chickpeas, spinach, onion,
                                                tomato,
                                                ginger, garlic, and warm spices.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chhole-Bhature.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chhole Bhature</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>A tasty Indian bread served with chickpeas</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Dal-Makhani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Dal Makhani</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p>This dal has whole black lentils cooked with butter and cream and
                                                simmered on low
                                                heat for that unique flavor. It tastes best with garlic naan!</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Dal-Tadka.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Dal Tadka</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p>Dal Tadka is a popular Indian lentil dish made with arhar dal (husked &
                                                split
                                                pigeon pea lentils) or masoor dal (husked & split red lentils).</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Kadai-Paneer.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Kadai Paneer</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>(Cottage cheese) Kadai Paneer is a spicy, warming, flavourful, and super
                                                delicious dish made by cooking panner & bell Peppers in a fragrant,
                                                fresh ground
                                                spice powder.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Kaju-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Kaju Curry</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Kaju curry is a delicious recipe of a creamy kaju butter masala with a
                                                rich,
                                                tangy, sweet flavorful gravy made with cashews, tomatoes, cream and
                                                spices.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Malai-Kofta.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Malai Kofta</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Vegetables and cottage cheese dumplings served in tangy cashew & Tomato
                                                gravy</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Methi-Malai-mutter.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Methi Malai mutter</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>A combination of fenugreek and garden peas in rich creamy gravy</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mirchi-Ka-Salan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mirchi Ka Salan</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p> A Popular green chili or Jalapeno , sesame, and peanut curry of
                                                Hyderabad</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mixed-Vegetable-Korma.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mixed Vegetable Korma</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>This super aromatic and delicious vegetable korma is made with potatoes,
                                                peas,
                                                carrots, French beans, onions, tomatoes, coconut or yogurt, nuts, and
                                                spices.
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mutter-Paneer.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mutter Paneer</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Matar paneer recipe is a popular Indian Curry dish made with green peas
                                                and
                                                Paneer (Indian cottage cheese) in a base of onions, tomatoes, cashews,
                                                spices
                                                and herbs. </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Palak-Paneer.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Palak Paneer</span> <span class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p>Palak paneer is a classic curried dish from North Indian cuisine made
                                                with fresh
                                                spinach, onions, spices, paneer, and herbs</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Paneer-Butter-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Paneer Butter Masala</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p>BButter Paneer masala is a recipe of delicious and hot thick gravy made
                                                with
                                                pieces of paneer mixed in a buttery sauce of tomatoes</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Paneer-Tikka-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Paneer Tikka Masala</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Soft melt-in-the-mouth tender chunks of marinated grilled panner swimming
                                                in a
                                                flavorsome spicy & creamy gravy.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Paneer-Burji.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Paneer Burji</span> <span class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p>Shredded paneer sauteed with onion, ginger, and tomatoes with spices</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Paneer-Pasanda.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Paneer Pasanda</span> <span class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p>A Creamy and rich Punjabi gravy made with shallow fried stuffed panner in
                                                smooth
                                                & creamy Onion gravy</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Kolhapuri.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Veg Kolhapuri</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Veggies cooked sauteed with sesame, coconut and tomato gravy in kolhapuri
                                                sauce
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Sambar.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Sambar (16 OZ)</span> <span class="dots"></span>
                                                <span class="price">$5.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Paneer-Korma.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Paneer Korma</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Gongura-Pappu.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Gongura Pappu (Andhra dal)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="NonVegCurry">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Boneless-Kadai.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Boneless Kadai</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Boneless chicken cubes Cooked wit bell peppers, tomato and onion a north
                                                western style</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Butter-Chicken.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Butter Chicken</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>The secret to the tender, flavor-infused chicken is a spice-infused
                                                yogurt marinade made with fresh ginger, garlic, lemon juice, and spices.
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Seekh-Kabab-Kadai.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Seekh Kabab Kadai</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Tikka-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Tikka Masala</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Marinated chicken breast grilled in charcoal clay oven and cooked with
                                                tomato
                                                creamy
                                                sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg curry</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Tikka-masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Tikka masala</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-tikka-masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat tikka masala</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Nellore-Chepala-Pulusu.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Nellore Chepala Pulusu</span> <span
                                                    class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Aachari.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Aachari</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Cooked on slow fire with a combination of pickling spices and herbs</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Goan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Goan</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Simmed in coconut milk, cooked with ginger, garlic, herbs and spices</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Gongura.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Gongura</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>South Indian style curry cooked with the gongura leaves sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Jalfrezi.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Jalfrezi</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Cooked with fresh veggies in tangy sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Kadai.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Kadai</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Cooked wit bell peppers, tomato and onion a north western style</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Korma.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Korma</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>A thick and aromatic creamy sauce with ground cashew nuts and mild spices
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Laal-Mas.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Laal Mas</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Mutton prepared in rich Rajasthani style with a sauce of yogurt and hot
                                                spices such as red mathania chilies</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Chetinadu.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Chetinadu</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>A flavorful traditional south Indian curry</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Laal-Mas.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Rojanjosh</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Cooked in freshly ground spices, yogurt and tomato flavored sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Saag.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Saag</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Incorporate your choice of meat with cooked fresh spinach, herbs and
                                                spices</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Vindaloo.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Vindaloo</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Slowly simmered in flary cooked in hot spicy sauce with potatoes</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Xacuti.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Xacuti</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Famous curry from Goa cooked with creamy coconut sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Aachari.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Aachari</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Cooked on slow fire with a combination of pickling spices and herbs</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Andhra-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Andhra Curry</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>The most famous traditional curry in Andhra region known for its
                                                spiciness</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Gaon.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Goan</span> <span class="dots"></span>
                                                <span class="price"></span>
                                            </h5>
                                            <p>simmed in coconut milk, cooked with ginger, garlic, herbs and spices</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Jalfrezi.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Jalfrezi</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Cooked with fresh veggies in tangy sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Kadai.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Kadai</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Cooked wit bell peppers, tomato and onion a north western style</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-korma.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Korma</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>A thick and aromatic creamy sauce with ground cashew nuts and mild spices
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Laal-Mas.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Laal Mas</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Mutton prepared in rich Rajasthani style with a sauce of yogurt and hot
                                                spices such as red mathania chilies</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Madras.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Madras</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>A flavorful traditional south Indian curry</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Rojanjosh.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Rojanjosh</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Cooked in freshly ground spices, yogurt and tomato flavored sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Saag.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Saag</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Incorporate your choice of meat with cooked fresh spinach, herbs and
                                                spices</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Vindaloo.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Vindaloo</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Slowly simmered in flary cooked in hot spicy sauce with potatoes</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Xacuti.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Xacuti</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Famous curry from Goa cooked with creamy coconut sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Aachari.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Aachari</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>Cooked on slow fire with a combination of pickling spices and herbs</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Andhra-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Andhra Curry</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>The most famous traditional curry in Andhra region known for its
                                                spiciness </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Tikka-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Goan</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>simmed in coconut milk, cooked with ginger, garlic, herbs and spices</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Gogura.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Gogura </span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>South Indian style curry cooked with the gongura leaves sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Jalfrezi.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Jalfrezi</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>Cooked with fresh veggies in tangy sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Kadai.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Kadai</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>Cooked wit bell peppers, tomato and onion a north western style</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Korma.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Korma</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>A thick and aromatic creamy sauce with ground cashew nuts and mild spices
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Laal-Mas.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Laal Mas</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>Mutton prepared in rich Rajasthani style with a sauce of yogurt and hot
                                                spices such as red mathania chilies</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Madras.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Madras</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>A flavorful traditional south Indian curry</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Rojanjosh.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Rojanjosh</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>Cooked in freshly ground spices, yogurt and tomato flavored sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Saag.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Saag</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>Incorporate your choice of meat with cooked fresh spinach, herbs and
                                                spices</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Vindaloo.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Vindaloo</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>Slowly simmered in flary cooked in hot spicy sauce with potatoes</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Xacuti.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Xacuti</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>Famous curry from Goa cooked with creamy coconut sauce</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Aachari.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Aachari</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Andhra-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Andhra Curry</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Goan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Goan</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Gogura.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Gogura</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Jalfrezi.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Jalfrezi</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Kadai.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Kadai</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Korma.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Korma</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Laal-Mas.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Laal Mas</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Madras.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Madras</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Rojanjosh.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Rojanjosh</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Saag.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Saag</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/lamb-Vindaloo.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Vindaloo</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Xacuti.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Xacuti</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Aachari.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Aachari</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Andhra-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Andhra Curry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Goan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Goan</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Jalfrezi.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Jalfrezi</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Kadai.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Kadai</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Korma.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Korma</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Laal-Mas.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Laal Mas</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Madras.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Madras</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Rojanjosh.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Rojanjosh</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Saag.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Saag</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Vindaloo.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Vindaloo</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Xacuti.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Xacuti</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Achari.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Achari</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p> </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Andhra-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Andhra Curry</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goan</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Gongura.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Gongura</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Jalfrezi.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Jalfrezi</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Kadai.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Kadai</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Korma.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Korma</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Laal-Mas.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Laal Mas</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Madras.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Madras</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Rogan-Josh.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Rogan Josh</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Saag.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Saag ( Palak)</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Vindaloo.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Vindaloo</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Xacuti.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Xacuti</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="BiryaniCornerRice">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-555-boneless-Biryani.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Chicken 555 boneless Biryani</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Panner-555-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Panner 555 Biryani</span> <span class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-65-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken 65 Biryani</span> <span class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p>Spicy Chicken 65 biryani is a special South Indian-inspired glorious
                                                layering
                                                irresistible chicken, basmati rice, fresh herbs, crispy onions, and a
                                                tiny drizzle of ghee. Perfect for entertaining!</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Biryani</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Marinated chicken and spices cooked with basmati rice on a low heat</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Biryani</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Fresh vegetables and boiled Egg cooked with basmati rice and fresh spices
                                                cooked
                                                on a low heat </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Extra-Biryani-Rice.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Extra Biryani Rice</span> <span class="dots"></span>
                                                <span class="price">$8.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Fish-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Fish Biryani</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Biryani</span> <span class="dots"></span>
                                                <span class="price">$18.99</span>
                                            </h5>
                                            <p>Goat with bone & spices cooked with basmati rice on a low heat</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Kheema-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Kheema Biryani</span> <span
                                                    class="dots"></span>
                                                <span class="price">$19.99</span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Roast-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Roast Biryani</span> <span class="dots"></span>
                                                <span class="price">$19.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Jeera-Rice.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Jeera Rice</span> <span class="dots"></span>
                                                <span class="price">$7.99</span>
                                            </h5>
                                            <p>Jeera rice is an Indian rice and cumin seeds dish</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mutton-Thalappakati-Biryani.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Mutton Thalappakati Biryani</span> <span
                                                    class="dots"></span>
                                                <span class="price">$19.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Natu-Kodi-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Natu Kodi Biryani</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Paneer-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title"> Paneer Biryani</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Paneer fried and cooked with delicious spices and rice</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Panner-Makhani-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title"> Panner Makhani Biryani</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Shrimp Biryani</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Veg Biryani</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Fresh vegetables cooked with basmati rice and fresh spices cooked on a
                                                low heat
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Makhani-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Veg Makhani Biryani</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Vijayawada-Chicken-boneless-Biryani.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Vijayawada Chicken boneless Biryani</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Vijayawada-Panner-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Vijayawada Panner Biryani</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Vijayawada-Veg-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Vijayawada Veg Biryani</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/White-Rice.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">White Rice</span> <span class="dots"></span>
                                                <span class="price">$4.99</span>
                                            </h5>
                                            <p>Steamed White Rice</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Hariyali-Boneless-Biryani.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Chicken Hariyali Boneless Biryani</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Panner-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Veg-Panner Biryani</span> <span class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Thalappakati-Biryani.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Chicken Thalappakati Biryani</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Panner-Hariyali-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Panner Hariyali Biryani</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="IndoChinese">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Spring-roll.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Veg Spring Rolls (5) Dry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$10.99</span>
                                            </h5>
                                            <p>Spring roll is a traditional Chinese savory snack where a pastry sheet is
                                                filled
                                                with vegetables, rolled & fried</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Baby-Corn-Chilli-Dry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Baby Corn Chilli Dry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$10.99</span>
                                            </h5>
                                            <p>Baby Corn tossed in soy & chilli sauce with green peppers and onions</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chili-Chicken-Garlic-Dry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Chili Chicken Garlic Dry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chili-Fish-Garlic-Dry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Chili Fish Garlic Dry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chili-Paneer-Dry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chili Paneer Dry
                                                </span> <span class="dots"></span> <span class="price">$12.99</span>
                                            </h5>
                                            <p>Stir-Fried panner tossed with diced onion and pepper in a spicy soy sauce
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chili-Shrimp-Garlic-Dry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chili Shrimp Garlic Dry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Gobi-Veg-Manchurian-Dry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Gobi/Veg Manchurian Dry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$11.99</span>
                                            </h5>
                                            <p>Gobi is tossed in tangy Manchurian sauce and green onions</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Fried-Rice.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Fried Rice</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Schezwan-Fried-Rice.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Veg Schezwan Fried Rice</span> <span
                                                    class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Paneer-Fried-Rice.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Paneer Fried Rice</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Fried-Rice.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Fried Rice</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chili-Gobi-Fried-Rice.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chili Gobi Fried Rice</span> <span
                                                    class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Schezuan-Fried-Rice.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Chicken Schezuan Fried Rice</span> <span
                                                    class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Hakka-Noodles.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Hakka Noodles</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Panner-Hakka-Noodles.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Panner Hakka Noodles</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Hakka-Noodles.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Hakka Noodles</span> <span
                                                    class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Gobi-Manchurian-Noodles.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Gobi Manchurian Noodles</span> <span
                                                    class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-Hakka-Noodles.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Hakka Noodles</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Hakka-Noodles.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Veg Hakka Noodles</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Fried-Rice.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Veg Fried Rice</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Hakka-Noodles.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Hakka Noodles</span> <span class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="DosaCorner">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Masala-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Masala Dosa</span> <span class="dots"></span>
                                                <span class="price">$11.99</span>
                                            </h5>
                                            <p>Thin rice crepe filled with potato stew served with chutney & sambar.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Ghee-Masala-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Ghee Masala Dosa </span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Thin rice crepe topped with ghee & filled with potato stew served with
                                                chutney &
                                                sambar.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Paper-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Paper Dosa</span> <span class="dots"></span>
                                                <span class="price">$11.99</span>
                                            </h5>
                                            <p>A fermented thin & crisp crepe made from rice served with chutney &
                                                sambar.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/joys-Special-Veg-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Joy's Special Veg Dosa</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Chef's Special Dosa - thin crisp crepe made with ghee and potato stew
                                                topped with
                                                onion, paneer, peas, and cashews served with chutney & sambar</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Rava-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Rava Dosa</span> <span class="dots"></span> <span
                                                    class="price">$13.99</span></h5>
                                            <p>Thin crispy rava crepe mildly spiced served with chutneys and sambar.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Onion-Rava-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Onion Rava Dosa</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Thin crispy rava sprinkled with chopped onions served with chutneys and
                                                sambar.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Rava-Masala-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Rava Masala Dosa
                                                </span> <span class="dots"></span> <span class="price">$14.99</span>
                                            </h5>
                                            <p>Thin crispy rava crepe stuffed with mildly spiced mashed potatoes served
                                                with
                                                chutneys and sambar.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Onion-Rava-Masala-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Onion Rava Masala Dosa</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>Thin crispy rava sprinkled with chopped onions served with chutneys and
                                                sambar.
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Joy-Special-Rava-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Joy Special Rava Dosa</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p>Thin crispy rava crepe cooked with ghee, mildly spiced and stuffed with
                                                onions,
                                                paneer, green peas, chestnut, and potatoes served with chutneys and
                                                sambar</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mysore-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mysore Dosa</span> <span class="dots"></span> <span
                                                    class="price">$11.99</span></h5>
                                            <p>Red chili chutney spread on thin rice and lentil crepe served with
                                                chutneys and
                                                sambar</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mysore-Masala-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mysore Masala Dosa</span> <span class="dots"></span>
                                                <span class="price">$11.99</span>
                                            </h5>
                                            <p>Red chili chutney spread on thin rice and lentil crepe filled with mashed
                                                potatoes and onions served with chutneys and sambar
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mysore-Rawa-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mysore Rawa Dosa</span> <span class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p>Red chili chutney spread on thin rice and lentil crepe filled with mashed
                                                potatoes and onions served with chutneys and sambar</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Kara-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Kara Dosa</span> <span class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p>Spicy thin rice crepe with spices, onions and potatoes served with
                                                chutneys and
                                                sambar</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Special-Ghee-Podi-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Special Ghee Podi Dosa</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p>South Indian style rice crepe sprinkled with ghee, filled with a mixture
                                                of
                                                ground dry spices containing dry chilies, black gram, chickpeas, and
                                                sesame
                                                seeds served with chutneys and sambar</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chettinad-Chiken-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chettinad Chiken Dosa
                                                </span> <span class="dots"></span> <span class="price">$15.99</span>
                                            </h5>
                                            <p>Thin rice & lentils crepe filled with South Indian style spicy chicken
                                                curry
                                                served with chutney & sambar</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Madurai-Muttai-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Madurai Muttai Dosa
                                                </span> <span class="dots"></span> <span class="price"> $13.99</span>
                                            </h5>
                                            <p>Thin rice & lentils battered crepe stuffed with South Indian Madurai city
                                                styled
                                                egg spiced served with chutney & samba</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Madurai-Mutton-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Madurai Mutton Dosa</span> <span
                                                    class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p>Thin rice & lentils battered crepe stuffed with South Indian Madurai city
                                                styled
                                                mutton (goat) curry served with chutney & sambar </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Spring-Masala-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Spring Masala Dosa
                                                </span> <span class="dots"></span> <span class="price">$12.99</span>
                                            </h5>
                                            <p>Thin rice crepe filled with stir fried vegetables served with chutney &
                                                sambar
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Cheese-Masala-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Cheese Masala Dosa
                                                </span> <span class="dots"></span> <span class="price">$15.99</span>
                                            </h5>
                                            <p>Thin rice crepe filled with cheese & potato stew served with chutney &
                                                sambar
                                            </p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Amul-Cheese-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Amul Cheese Dosa</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>Grated Indian Amul cheese Topping on dosa</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Amul-Cheese-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Amul Cheese Dosa</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p>Grated Indian Amul cheese Topping on dosa</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Idlli.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Idlli (3)</span> <span class="dots"></span>
                                                <span class="price">$8.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="ParthaCorner">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Partha-with-Veg-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Partha (2) with Veg Curry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Partha-with-Egg-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Partha (2) with Egg Masala (8 Oz)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Partha-with-Chicken-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Partha (2) with Chicken Curry (8 Oz)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$13.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Partha-with-Lamb-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Partha (2) with Lamb Curry (8 Oz)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Partha-with-Goat-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Partha (2) with Goat Curry (8 Oz)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Kotthu-Partha.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Veg Kotthu Partha</span> <span class="dots"></span>
                                                <span class="price">$14.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Kotthu-Partha.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Kotthu Partha</span> <span
                                                    class="dots"></span>
                                                <span class="price">$15.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Kotthu-Partha.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Kotthu Partha</span> <span class="dots"></span>
                                                <span class="price">$17.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="IndianBreadRotisNaans">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Butter-Naan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Butter Naan</span><span class="dots"></span>
                                                <span class="price">$3.49</span>
                                            </h5>
                                            <p>Unleavened bread cooked on a live fire in clay oven</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chilli-Garlic-Naan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chilli Garlic Naan</span> <span class="dots"></span>
                                                <span class="price">$4.49</span>
                                            </h5>
                                            <p>Special Bread stuffed cooked on a live fire in clay oven</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chilli-Naan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chilli Naan</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                            <p>Bread stuffed with green chilies cooked on a live fire in clay oven</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Garlic-Naan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Garlic Naan</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                            <p>Bread made with chopped garlic and cilantro on the top</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Plain-Naan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Plain Naan </span> <span class="dots"></span>
                                                <span class="price">$3.49</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Aloo-Paratha.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoori Aloo Paratha</span> <span
                                                    class="dots"></span>
                                                <span class="price">$5.99</span>
                                            </h5>
                                            <p>Wheat bread stuffed with mildly spiced potatoes</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Paneer-Paratha.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoori Paneer Paratha</span> <span
                                                    class="dots"></span>
                                                <span class="price">$5.99</span>
                                            </h5>
                                            <p>Wheat bread stuffed with mildly spiced Paneer</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Plain-Paratha.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoori Plain Paratha
                                                </span> <span class="dots"></span> <span class="price">$4.99</span></h5>
                                            <p>Whole wheat bread</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandorri-Roti.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandorri Roti</span> <span class="dots"></span>
                                                <span class="price">$3.49</span>
                                            </h5>
                                            <p>Whole wheat bread cooked in clay oven on live fire</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Amul-Cheese-Naan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Amul Cheese Naan
                                                </span> <span class="dots"></span> <span class="price">$7.99</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Kashmiri-Naan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Kashmiri Naan</span> <span class="dots"></span>
                                                <span class="price">$4.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Malbar-Paratha.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Malbar Paratha (2) = Lacha</span> <span
                                                    class="dots"></span>
                                                <span class="price">$5.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Bhatura.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Bhatura</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Seseme-Naan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Seseme Naan</span><span class="dots"></span>
                                                <span class="price">$3.49</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Peshawari-Naan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Peshawari Naan</span> <span class="dots"></span>
                                                <span class="price">$3.75</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tandoori-Gobi-Paratha.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tandoori Gobi Paratha</span> <span
                                                    class="dots"></span>
                                                <span class="price">$5.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Punjabi-Naan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Punjabi Naan</span> <span class="dots"></span>
                                                <span class="price">$3.49</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="Condiments">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Raita.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Raita (4 Oz)</span> <span class="dots"></span>
                                                <span class="price">$1.99</span>
                                            </h5>
                                            <p>Mild yogurt sauce with shredded carrots,cucumber and jeera powder</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Salan.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Salan (8 Oz)</span> <span class="dots"></span>
                                                <span class="price">$2.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Onion-chillis-lemons.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Onion chilli's lemons</span> <span
                                                    class="dots"></span>
                                                <span class="price">$1.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="Desserts">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Ras-Malai.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Ras Malai</span> <span class="dots"></span>
                                                <span class="price">$4.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Gulab-Jamun.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Gulab Jamun</span> <span class="dots"></span>
                                                <span class="price">$4.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Kala-Jamun.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Kala Jamun</span> <span class="dots"></span>
                                                <span class="price">$5.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Carrot-Halwa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Carrot Halwa</span> <span class="dots"></span>
                                                <span class="price">$5.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="Specials">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mutton-Haleem-Spicy.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mutton Haleem - Spicy</span> <span
                                                    class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Custom-Chicken-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Custom Chicken Curry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Custom-Mutton-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Custom Mutton Curry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$18.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Custom-Lamb-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Custom Lamb Curry</span> <span class="dots"></span>
                                                <span class="price">$19.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Shrimp-special.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Shrimp Special</span> <span class="dots"></span>
                                                <span class="price">$18.99</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mutton-Haleem.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mutton Haleem</span> <span class="dots"></span>
                                                <span class="price">$16.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="Chat">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Samosa-chat.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Samosa chat</span> <span class="dots"></span>
                                                <span class="price">$8.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/sample-chat.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">sample</span> <span class="dots"></span>
                                                <span class="price">$0.01</span>
                                            </h5>
                                            <p>Mango Lassi</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="CakeandBakery">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Puff.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Puff</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Choclate-Cookies.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Choclate Cookies</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Cream-Bun.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Cream Bun</span> <span class="dots"></span>
                                                <span class="price"><s>$2.45</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Egg-Puff.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Egg Puff</span> <span class="dots"></span>
                                                <span class="price">$3.25</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Veg-Puff.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Veg Puff</span> <span class="dots"></span>
                                                <span class="price">$2.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Dil-pasand.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Dil pasand</span> <span class="dots"></span> <span
                                                    class="price"><s>$2.99</s></span></h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Dil-Kush.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Dil Kush</span> <span class="dots"></span>
                                                <span class="price">$2.99</span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chocolate-Moose.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chocolate Moose</span> <span class="dots"></span>
                                                <span class="price"><s>$3.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mango-Moose.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mango Moose</span> <span class="dots"></span>
                                                <span class="price"><s>$3.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Ragi-Cookies.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Ragi Cookies</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/coconut-cookies.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">coconut cookies</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Dry-Fruit-Cokkie.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Dry Fruit Cokkie</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Cookies-half-Moon.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Cookies half Moon</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Nan-khatai-Biscuit.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Nan khatai Biscuit</span> <span class="dots"></span>
                                                <span class="price"><s>$3.99</s></span></h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Jeeri-Cookies-Salt.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Jeeri Cookies Salt</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Kari-Puff-snack.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Kari Puff snack</span> <span class="dots"></span>
                                                <span class="price"><s>$1.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Pav-Bread.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Pav Bread</span> <span class="dots"></span>
                                                <span class="price"><s>$2.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Cream-Cone.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Cream Cone</span> <span class="dots"></span>
                                                <span class="price"><s>$2.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Browny.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Browny</span> <span class="dots"></span>
                                                <span class="price"><s>$2.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Assorted-Cookies.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Assorted Cookies</span> <span class="dots"></span>
                                                <span class="price">$4.50</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Plum-Cake.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Plum Cake</span> <span class="dots"></span>
                                                <span class="price">$4.50</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Dry-Fruit-Cake.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Dry Fruit Cake</span> <span class="dots"></span>
                                                <span class="price">$4.50</span></h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Palmiers.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Palmiers</span> <span class="dots"></span>
                                                <span class="price"><s>$1.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Butter-Scott-Pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Butter Scott Pastry</span> <span
                                                    class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mango-Pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mango Pastry</span> <span class="dots"></span>
                                                <span class="price"><s>$3.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Oreo-Pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Oreo Pastry</span> <span class="dots"></span>
                                                <span class="price"><s>$4.25</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chocolate-Pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chocolate Pastry</span> <span class="dots"></span>
                                                <span class="price"><s>$4.25</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Rasamalai-Pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Rasamalai Pastry</span> <span class="dots"></span>
                                                <span class="price">$4.25</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Pistachio-Pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Pistachio Pastry</span> <span class="dots"></span>
                                                <span class="price"><s>$3.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tres-leches.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Tres leches</span> <span class="dots"></span>
                                                <span class="price"><s>$4.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Black-Forest-Pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Black Forest Pastry</span> <span
                                                    class="dots"></span>
                                                <span class="price"><s>$3.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Gulab-Jamoon-Pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Gulab Jamoon Pastry</span> <span
                                                    class="dots"></span>
                                                <span class="price"><s>$4.25</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Pineapple-Pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Pineapple Pastry</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Straw-Berry-Pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Straw Berry Pastry</span> <span class="dots"></span>
                                                <span class="price"><s>$3.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Cream-Cone.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Cream Cone</span> <span class="dots"></span>
                                                <span class="price"><s>$2.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/KitKat-pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">KitKat pastry</span> <span class="dots"></span>
                                                <span class="price"><s>$3.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Irish-coffee-pastry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Irish coffee pastry</span> <span
                                                    class="dots"></span>
                                                <span class="price"><s>$3.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">OUT OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Butter-Scott-Cake.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Butter Scott Cake - 8 Inch - 2LB</span> <span
                                                    class="dots"></span> <span class="price">$43.00</span></h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mango-Cake.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mango Cake - 8 Inch - 2LB</span> <span
                                                    class="dots"></span>
                                                <span class="price">$43.00</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chocolate-Cake.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Chocolate Cake - 8 Inch - 2LB</span> <span
                                                    class="dots"></span>
                                                <span class="price">$43.00</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Oreo-Cake.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Oreo Cake - 8 Inch - 2LB</span> <span
                                                    class="dots"></span>
                                                <span class="price">$43.00</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/KitKat-cake.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">KitKat Cake - 8 Inch - 2LB</span> <span
                                                    class="dots"></span>
                                                <span class="price">$43.00</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Strawberry-Cake.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Strawberry Cake - 8 Inch - 2LB</span> <span
                                                    class="dots"></span>
                                                <span class="price">$40.00</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Tres-leche-Cake.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Tres leche Cake - 8 Inch - 2LB</span> <span
                                                    class="dots"></span>
                                                <span class="price">$43.00</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Pistachio-Cake.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Pistachio Cake - 8 Inch - 2LB</span> <span
                                                    class="dots"></span>
                                                <span class="price">$40.00</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/KitKat.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">KitKat- 8 Inch - 2LB</span> <span
                                                    class="dots"></span>
                                                <span class="price">$43.00</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Black-Forest.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Black Forest - 8 Inch - 2LB</span> <span
                                                    class="dots"></span>
                                                <span class="price">$43.00</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Rasmalai-Cake.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Rasmalai Cake 8 Inch (2 LB)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$43.00</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Gulab-Jamoon.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5>
                                                <span class="title">Gulab Jamoon - 8 Inch - 2LB</span> <span
                                                    class="dots"></span>
                                                <span class="price">$43.00</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="Pickles">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-pickle-8-oz.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken pickle 8 oz</span> <span
                                                    class="dots"></span>
                                                <span class="price">$6.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="FamilyPackBiryaniOnly">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Biryani - 2 People</span> <span
                                                    class="dots"></span>
                                                <span class="price">$23.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Vijayawada-Biryani.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Vijayawada Biryani - 2 People</span> <span
                                                    class="dots"></span>
                                                <span class="price">$25.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-65-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken 65 Biryani - 2 People</span> <span
                                                    class="dots"></span>
                                                <span class="price">$25.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Biryani - 5-6 People</span> <span
                                                    class="dots"></span>
                                                <span class="price">$44.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-65-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken 65 Biryani - 5-6 People</span> <span
                                                    class="dots"></span>
                                                <span class="price">$49.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Chicken-Vijayawada-Biryani.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Chicken Vijayawada Biryani - 5-6 People</span> <span
                                                    class="dots"></span> <span class="price">$49.99</span></h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Biryani - 2 people</span> <span
                                                    class="dots"></span>
                                                <span class="price">$32.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Goat-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Goat Biryani - 5-6 People</span> <span
                                                    class="dots"></span>
                                                <span class="price">$64.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Biryani 2 People</span> <span
                                                    class="dots"></span>
                                                <span class="price">$32.99</span>
                                            </h5>
                                            <p>Soda Can</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Lamb-Biryani.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Lamb Biryani 5-6 People</span> <span
                                                    class="dots"></span>
                                                <span class="price">$64.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="IndianTiffinsMenu">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Idlli.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Idly (2)</span> <span class="dots"></span>
                                                <span class="price">$5.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Idly-Sambar.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Idly Sambar (2)</span> <span class="dots"></span>
                                                <span class="price">$6.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Idly-Vada.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Idly (2) Vada ( 1)</span> <span class="dots"></span>
                                                <span class="price">$8.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Sambar-Idly-Vada.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Sambar Idly (2) Vada ( 1)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$9.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Set-Dosa.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Set-Dosa ( 3)</span> <span class="dots"></span>
                                                <span class="price">$9.99</span></h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Set-Dosa-Chicken-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Set-Dosa - Chicken Curry (8 Oz)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$11.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Vada-Chicken-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Vada (3) - Chicken Curry ( 8 Oz)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$11.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Idly-Chicken-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Idly(3) - Chicken Curry ( 8 Oz)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$11.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Upma.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Upma (Saturday, Sunday)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$6.99</span>
                                            </h5>
                                            <p></p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Pongal.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Pongal (Saturday, Sunday)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$8.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Puri-Aloo-Masala.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Puri ( 2) Aloo Masala</span> <span
                                                    class="dots"></span>
                                                <span class="price">$9.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Puri-Chicken-Curry.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Puri (2) Chicken Curry (8 Oz)</span> <span
                                                    class="dots"></span>
                                                <span class="price">$12.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Vada.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Vada (2)</span> <span class="dots"></span>
                                                <span class="price">$5.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="Beverages">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <ul class="two-column">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Black-Tea.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Black Tea</span> <span class="dots"></span>
                                                <span class="price">$2.50</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Butter-Milk.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Butter Milk</span> <span class="dots"></span>
                                                <span class="price">$3.50</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Coffee.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Coffee</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Frooty.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Frooty</span> <span class="dots"></span>
                                                <span class="price"><s>$1.99</s></span>
                                            </h5>
                                            <p class="outofstock-text">Out OF STOCK</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Limca-Bottle.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Limca Bottle</span> <span class="dots"></span> <span
                                                    class="price">$3.99</span></h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Limca-Can.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Limca Can</span> <span class="dots"></span>
                                                <span class="price">$2.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mango-Lassi.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mango Lassi</span> <span class="dots"></span>
                                                <span class="price">$4.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Masala-Tea.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Masala Tea</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                            <p>Indian Spiced tea.</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Mexican-Glass-Bottled-Soda.jpg"
                                                alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Mexican Glass Bottled Soda</span> <span
                                                    class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                            <p>Coke/Sprite/Fanta</p>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Soda-Can.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Soda Can - Regular</span> <span class="dots"></span>
                                                <span class="price">$2.45</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Sweet-Lassi.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Sweet Lassi</span> <span class="dots"></span>
                                                <span class="price">$4.49</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Thumbs-up.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Thumbs up</span> <span class="dots"></span>
                                                <span class="price">$2.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Water.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Water Bottle</span> <span class="dots"></span>
                                                <span class="price">$1.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Yogurt-Plain.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Yogurt Plain</span> <span class="dots"></span>
                                                <span class="price">$3.49</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Diet-Soda-Can.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Diet - Soda Can</span> <span class="dots"></span>
                                                <span class="price">$2.45</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Coke-bottle.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Coke bottle</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Rose-milk.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Rose milk</span> <span class="dots"></span>
                                                <span class="price">$4.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Jarritos.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Jarritos</span> <span class="dots"></span>
                                                <span class="price">$3.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="Buffet">
                        <div class="row">
                            <div class="col-lg-12 pb-30">
                                <h6>Break-Fast Buffet (Dine-in Only)</h6>
                                <ul class="two-column mb-4">
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Breakfast-Buffet-Adult.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Breakfast Buffet - Adult</span> <span
                                                    class="dots"></span>
                                                <span class="price">$11.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                    <li class="food-menu-item style-two">
                                        <div class="image">
                                            <img src="assets/images/menu/Breakfast-Buffet-Kid.jpg" alt="Food Menu">
                                        </div>
                                        <div class="content">
                                            <h5><span class="title">Breakfast Buffet - Kid</span> <span
                                                    class="dots"></span>
                                                <span class="price">$8.99</span>
                                            </h5>
                                        </div>
                                    </li>
                                </ul>
                                <h6>Break-Fast Buffet (Dine-in Only)</h6>
                                <p>Coming soon</p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>