<section class="faq-area pt-80 pb-80 rel z-1 bg-white"
    style="z-index: -1; background: url('https://crunchbury.in/wp-content/themes/kadence/images/bg/bg-product-faq.png'); background-size: cover; background-position-y: bottom;">
    <div class="container">
        <div class="row">
            <div class="col-lg-5"></div>
            <div class="col-lg-7">
                <div class="fpq-part aos-init aos-animate" data-aos="fade-right" data-aos-duration="1500"
                    data-aos-offset="50">

                    <!-- Dynamic Heading -->
                    <h3>Frequently Asked Questions</h3>

                    <!-- Dynamic FAQ Accordion -->
                    <div id="faq-accordion" class="accordion mt-4">
                        <div class="accordion-item">
                            <h5 class="accordion-header">
                                <button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapse1">
                                    What dishes is Joys Biryani known for?</button>
                            </h5>
                            <div id="collapse1" class="accordion-collapse collapse"
                                data-bs-parent="#faq-accordion">
                                <div class="accordion-body">
                                    <p>At Joys Biryani, we are renowned for our delicious offerings, including a
                                        variety of biryanis, flavorful kebabs, and other Indian delicacies. We also
                                        serve delectable desserts like cheesecake and tiramisu, along with appetizers
                                        such as garlic bread and chicken wings.</p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h5 class="accordion-header">
                                <button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapse2">
                                    What meals do you serve?</button>
                            </h5>
                            <div id="collapse2" class="accordion-collapse collapse " data-bs-parent="#faq-accordion">
                                <div class="accordion-body">
                                    <p>We proudly serve both lunch and dinner to satisfy your cravings throughout the
                                        day.</p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h5 class="accordion-header">
                                <button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapse3">
                                    Do you offer delivery or takeout?</button>
                            </h5>
                            <div id="collapse3" class="accordion-collapse collapse " data-bs-parent="#faq-accordion">
                                <div class="accordion-body">
                                    <p>Yes, we offer both delivery and takeout options, making it easy for you to enjoy
                                    our delicious meals at home or on the go.                                   

                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h5 class="accordion-header">
                                <button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapse4">
                                What areas do you serve?
                                </button>
                            </h5>
                            <div id="collapse4" class="accordion-collapse collapse " data-bs-parent="#faq-accordion">
                                <div class="accordion-body">
                                    <p>Joys Biryani is delighted to serve the vibrant community surrounding our
                                    location at 212 N Polk St #101, Pineville, NC 28134, United States. Nestled in
                                    the heart of Pineville, we are conveniently accessible to food lovers in nearby
                                    neighborhoods and towns.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>